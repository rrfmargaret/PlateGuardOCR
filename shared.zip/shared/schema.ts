import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const plateRecords = pgTable("plate_records", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  plateNumber: text("plate_number").notNull(),
  confidence: real("confidence").notNull(), // 0-100 percentage
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  imageData: text("image_data"), // base64 encoded image
  processed: integer("processed").default(1).notNull(), // 0=failed, 1=success
  notes: text("notes"),
});

export const insertPlateRecordSchema = createInsertSchema(plateRecords).omit({
  id: true,
  timestamp: true,
});

export type InsertPlateRecord = z.infer<typeof insertPlateRecordSchema>;
export type PlateRecord = typeof plateRecords.$inferSelect;
